"""
KalshiBot Launcher
- Shows a setup/settings GUI on first run (tkinter)
- Saves config to kalshi_config.json next to the exe
- Starts the bot + dashboard server
- Opens browser automatically
"""

import sys
import os
import json
import threading
import webbrowser
import time
import tkinter as tk
from tkinter import messagebox, filedialog
from pathlib import Path

# ── Bundle path resolution ────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    BASE_DIR = sys._MEIPASS
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

sys.path.insert(0, BASE_DIR)

# Store config and trades in %APPDATA%\KalshiBot so the exe can run from anywhere
APP_DATA = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "KalshiBot")
os.makedirs(APP_DATA, exist_ok=True)
os.chdir(APP_DATA)   # trades.json will save here too

CONFIG_FILE = os.path.join(APP_DATA, "kalshi_config.json")
PORT = 5050

# ── Config helpers ────────────────────────────────────────────────────────────

DEFAULT_CONFIG = {
    "api_key":        "",
    "paper_mode":     True,
    "order_dollars":  10.0,
    "max_daily_loss": 20.0,
    "yes_only":       True,
    "scale_down":     True,
    "trigger_price":  70,
    "exit_price":     55,
    "stop_cushion":   12,
    "trail_distance": 8,
    "velocity_exit":  8,
    "stall_exit":     180,
}

def load_config():
    try:
        if Path(CONFIG_FILE).exists():
            data = json.loads(Path(CONFIG_FILE).read_text())
            return {**DEFAULT_CONFIG, **data}
    except Exception:
        pass
    return dict(DEFAULT_CONFIG)

def save_config(cfg):
    Path(CONFIG_FILE).write_text(json.dumps(cfg, indent=2))

# ── Palette ───────────────────────────────────────────────────────────────────
BG      = "#0a0e14"
FG      = "#c8d8e8"
GREEN   = "#00e5a0"
ACCENT  = "#00aaff"
WARN    = "#f5a623"
BORDER  = "#243040"
SURFACE = "#0e1318"
RED     = "#ff4466"
DIM     = "#4a6070"

# ── Settings GUI ──────────────────────────────────────────────────────────────

class SettingsWindow:
    def __init__(self, cfg, on_launch):
        self.cfg       = cfg
        self.on_launch = on_launch

        self.root = tk.Tk()
        self.root.title("KalshiBot — Setup")
        self.root.configure(bg=BG)
        self.root.resizable(False, False)

        # Fixed size, centered
        W, H = 560, 720
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")

        self._build()
        self.root.mainloop()

    def _build(self):
        r = self.root

        # ── Header bar ────────────────────────────────────────────────────────
        hdr = tk.Frame(r, bg=SURFACE, height=52)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        tk.Label(hdr, text="●", fg=GREEN, bg=SURFACE,
                 font=("Courier New", 13)).place(x=18, y=14)
        tk.Label(hdr, text="KALSHI BTC BOT", fg=ACCENT, bg=SURFACE,
                 font=("Courier New", 13, "bold")).place(x=38, y=14)
        tk.Label(hdr, text="15-MIN MARKET", fg=WARN, bg=SURFACE,
                 font=("Courier New", 10)).place(x=390, y=17)

        # thin accent line under header
        tk.Frame(r, bg=BORDER, height=1).pack(fill="x")

        # ── Body ──────────────────────────────────────────────────────────────
        body = tk.Frame(r, bg=BG, padx=30, pady=22)
        body.pack(fill="both", expand=True)

        # ── Trading Mode ──────────────────────────────────────────────────────
        self._label(body, "TRADING MODE")

        self.paper_var = tk.BooleanVar(value=self.cfg.get("paper_mode", True))

        btn_frame = tk.Frame(body, bg=BG)
        btn_frame.pack(fill="x", pady=(6, 18))

        self.paper_btn = tk.Radiobutton(
            btn_frame, text="📄  PAPER TRADING  (no real money)",
            variable=self.paper_var, value=True,
            bg=BG, fg=FG, selectcolor=SURFACE, activebackground=BG,
            font=("Courier New", 10), indicatoron=0, relief="flat",
            bd=1, padx=16, pady=11,
            command=self._on_mode_change)
        self.paper_btn.pack(side="left", padx=(0, 10))

        self.live_btn = tk.Radiobutton(
            btn_frame, text="💰  LIVE TRADING",
            variable=self.paper_var, value=False,
            bg=BG, fg=RED, selectcolor=SURFACE, activebackground=BG,
            font=("Courier New", 10), indicatoron=0, relief="flat",
            bd=1, padx=16, pady=11,
            command=self._on_mode_change)
        self.live_btn.pack(side="left")

        # ── API Key ID ────────────────────────────────────────────────────────
        self._label(body, "KALSHI API KEY ID")

        key_wrap = tk.Frame(body, bg=BORDER, padx=1, pady=1)
        key_wrap.pack(fill="x", pady=(6, 4))

        self.api_var = tk.StringVar(value=self.cfg.get("api_key", ""))
        self.api_entry = tk.Entry(
            key_wrap, textvariable=self.api_var,
            bg=SURFACE, fg=FG, insertbackground=FG,
            font=("Courier New", 11), relief="flat", bd=0,
            highlightthickness=0)
        self.api_entry.pack(fill="x", ipady=10, padx=8)

        # ── Private Key File ──────────────────────────────────────────────────
        self._label(body, "PRIVATE KEY FILE  (.pem)")

        pem_row = tk.Frame(body, bg=BG)
        pem_row.pack(fill="x", pady=(6, 4))

        pem_wrap = tk.Frame(pem_row, bg=BORDER, padx=1, pady=1)
        pem_wrap.pack(side="left", fill="x", expand=True, padx=(0, 8))

        self.pem_var = tk.StringVar(value=self.cfg.get("pem_path", ""))
        self.pem_entry = tk.Entry(
            pem_wrap, textvariable=self.pem_var,
            bg=SURFACE, fg=DIM, insertbackground=FG,
            font=("Courier New", 9), relief="flat", bd=0,
            highlightthickness=0)
        self.pem_entry.pack(fill="x", ipady=10, padx=8)

        tk.Button(pem_row, text="Browse...",
                  command=self._browse_pem,
                  bg=SURFACE, fg=ACCENT,
                  font=("Courier New", 9), relief="flat", bd=0,
                  padx=10, pady=6, cursor="hand2",
                  highlightthickness=1, highlightbackground=BORDER,
                  activebackground=BG, activeforeground=ACCENT
                  ).pack(side="left")

        self.api_hint = tk.Label(
            body, text="", fg=DIM, bg=BG,
            font=("Courier New", 9), anchor="w", wraplength=480, justify="left")
        self.api_hint.pack(fill="x", pady=(4, 14))

        # ── Dollars Per Trade ─────────────────────────────────────────────────
        self._label(body, "DOLLARS PER TRADE")

        amt_frame = tk.Frame(body, bg=BG)
        amt_frame.pack(fill="x", pady=(6, 4))

        tk.Label(amt_frame, text="$", fg=GREEN, bg=BG,
                 font=("Courier New", 18, "bold")).pack(side="left", padx=(0, 4))

        dollars_wrap = tk.Frame(amt_frame, bg=BORDER, padx=1, pady=1)
        dollars_wrap.pack(side="left")

        self.dollars_var = tk.StringVar(value=str(int(self.cfg.get("order_dollars", 10))))
        tk.Entry(
            dollars_wrap, textvariable=self.dollars_var,
            bg=SURFACE, fg=GREEN, insertbackground=GREEN,
            font=("Courier New", 16, "bold"), relief="flat", bd=0,
            highlightthickness=0, width=7).pack(ipady=8, padx=8)

        tk.Label(
            amt_frame,
            text="  Bot calculates contracts automatically from the price at entry",
            fg=DIM, bg=BG, font=("Courier New", 9)).pack(side="left")

        # ── Max Daily Loss ────────────────────────────────────────────────────
        self._label(body, "MAX DAILY LOSS  (auto-stop)")

        loss_outer = tk.Frame(body, bg=BG)
        loss_outer.pack(fill="x", pady=(6, 18))

        saved_loss = self.cfg.get("max_daily_loss", 0)
        self.loss_enabled_var = tk.BooleanVar(value=saved_loss > 0)

        self.loss_check = tk.Checkbutton(
            loss_outer, text="Enable  $",
            variable=self.loss_enabled_var,
            command=self._on_loss_toggle,
            bg=BG, fg=FG, selectcolor=SURFACE, activebackground=BG,
            font=("Courier New", 10), relief="flat", bd=0)
        self.loss_check.pack(side="left")

        loss_wrap = tk.Frame(loss_outer, bg=BORDER, padx=1, pady=1)
        loss_wrap.pack(side="left")

        self.loss_var = tk.StringVar(value=str(int(saved_loss)) if saved_loss > 0 else "20")
        self.loss_entry = tk.Entry(
            loss_wrap, textvariable=self.loss_var,
            bg=SURFACE, fg=RED, insertbackground=RED,
            font=("Courier New", 14, "bold"), relief="flat", bd=0,
            highlightthickness=0, width=6)
        self.loss_entry.pack(ipady=8, padx=8)

        tk.Label(loss_outer, text="  per session (0 = no limit)",
            fg=DIM, bg=BG, font=("Courier New", 9)).pack(side="left")

        # ── Strategy Options ──────────────────────────────────────────────────
        self._label(body, "STRATEGY OPTIONS")

        opts_frame = tk.Frame(body, bg=BG)
        opts_frame.pack(fill="x", pady=(6, 18))

        self.yes_only_var = tk.BooleanVar(value=self.cfg.get("yes_only", False))
        tk.Checkbutton(opts_frame, text="YES only  (skip NO/DOWN trades — recommended)",
            variable=self.yes_only_var,
            bg=BG, fg=FG, selectcolor=SURFACE, activebackground=BG,
            font=("Courier New", 10), relief="flat", bd=0).pack(anchor="w", pady=(0,6))

        self.scale_down_var = tk.BooleanVar(value=self.cfg.get("scale_down", False))
        tk.Checkbutton(opts_frame, text="Scale down after stop-loss  (halve size, restore on win)",
            variable=self.scale_down_var,
            bg=BG, fg=FG, selectcolor=SURFACE, activebackground=BG,
            font=("Courier New", 10), relief="flat", bd=0).pack(anchor="w")

        # ── Launch button ─────────────────────────────────────────────────────
        tk.Frame(r, bg=BORDER, height=1).pack(fill="x")

        btn_outer = tk.Frame(r, bg=BG, pady=18, padx=30)
        btn_outer.pack(fill="x")

        self.launch_btn = tk.Button(
            btn_outer,
            text="▶   LAUNCH BOT",
            command=self._launch,
            bg=GREEN, fg="#000000",
            font=("Courier New", 13, "bold"),
            relief="flat", bd=0,
            padx=0, pady=14,
            cursor="hand2",
            activebackground="#00c87a",
            activeforeground="#000000")
        self.launch_btn.pack(fill="x")

        self._on_mode_change()
        self._on_loss_toggle()

    def _label(self, parent, text):
        row = tk.Frame(parent, bg=BG)
        row.pack(fill="x", pady=(0, 2))
        tk.Label(row, text=text, fg=DIM, bg=BG,
                 font=("Courier New", 8)).pack(side="left")
        tk.Frame(row, bg=BORDER, height=1).pack(
            side="left", fill="x", expand=True, padx=(8, 0), pady=4)

    def _on_loss_toggle(self):
        if not hasattr(self, 'loss_enabled_var') or not hasattr(self, 'loss_entry'):
            return
        if self.loss_enabled_var.get():
            self.loss_entry.config(state="normal", fg=RED)
        else:
            self.loss_entry.config(state="disabled", fg=DIM)

    def _browse_pem(self):
        path = filedialog.askopenfilename(
            title="Select your Kalshi private key",
            filetypes=[("Key files", "*.pem *.key *.txt"), ("PEM files", "*.pem"), ("Text files", "*.txt"), ("All files", "*.*")]
        )
        if path:
            self.pem_var.set(path)

    def _on_mode_change(self):
        is_paper = self.paper_var.get()
        if is_paper:
            self.api_hint.config(
                text="Not required for paper trading.")
            self.api_entry.config(fg=DIM)
            self.pem_entry.config(fg=DIM)
        else:
            self.api_hint.config(
                text="Get your Key ID and generate a .pem file at kalshi.com → Settings → API")
            self.api_entry.config(fg=FG)
            self.pem_entry.config(fg=FG)

    def _launch(self):
        paper_mode = self.paper_var.get()
        api_key    = self.api_var.get().strip()
        pem_path   = self.pem_var.get().strip()

        try:
            dollars = float(self.dollars_var.get().replace("$", "").strip())
            if dollars <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Amount",
                "Please enter a valid dollar amount (e.g. 10)")
            return

        if not paper_mode:
            if not api_key:
                messagebox.showerror("API Key ID Required",
                    "Please enter your Kalshi API Key ID.\n\n"
                    "Find it at: kalshi.com → Settings → API")
                return
            if not pem_path:
                messagebox.showerror("Private Key Required",
                    "Please select your private key .pem file.\n\n"
                    "Generate one at: kalshi.com → Settings → API")
                return
            import os
            if not os.path.exists(pem_path):
                messagebox.showerror("File Not Found",
                    f"Could not find private key file:\n{pem_path}")
                return

        if self.loss_enabled_var.get():
            try:
                max_loss = float(self.loss_var.get().replace("$","").strip())
                if max_loss <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Invalid Amount", "Please enter a valid max loss amount (e.g. 20)")
                return
        else:
            max_loss = 0.0  # 0 = no limit

        yes_only   = self.yes_only_var.get()
        scale_down = self.scale_down_var.get()
        save_config({"api_key": api_key, "pem_path": pem_path,
                     "paper_mode": paper_mode, "order_dollars": dollars,
                     "max_daily_loss": max_loss, "yes_only": yes_only,
                     "scale_down": scale_down,
                     "trigger_price": self.cfg.get("trigger_price", 70),
                     "exit_price":    self.cfg.get("exit_price", 55),
                     "stop_cushion": self.cfg.get("stop_cushion", 12)})
        self.root.destroy()
        combined = f"{api_key}::{pem_path}" if not paper_mode else "PAPER_MODE_NO_KEY"
        self.on_launch(combined, paper_mode, dollars, max_loss, yes_only, scale_down)


# ── Bot launcher ──────────────────────────────────────────────────────────────

def launch_bot(api_key, paper_mode, order_dollars, max_daily_loss=20.0, yes_only=False, scale_down=False):
    # Read saved strategy settings from config file
    _saved = load_config()
    try:
        import bot as bot_module
        bot_module.ORDER_DOLLARS  = order_dollars
        bot_module.MAX_DAILY_LOSS = max_daily_loss
        bot_module.YES_ONLY       = yes_only
        bot_module.SCALE_DOWN_AFTER_LOSS = scale_down
        bot_module.TRIGGER_PRICE  = _saved.get("trigger_price", 70)
        bot_module.EXIT_PRICE     = _saved.get("exit_price", 55)
        bot_module.STOP_CUSHION   = _saved.get("stop_cushion", 20)
        bot_module.update_state(order_dollars=order_dollars, max_daily_loss=max_daily_loss,
                                yes_only=yes_only, scale_down=scale_down,
                                trigger_price=bot_module.TRIGGER_PRICE,
                                exit_price=bot_module.EXIT_PRICE,
                                stop_cushion=bot_module.STOP_CUSHION)
    except Exception as e:
        messagebox.showerror("Startup Error",
            f"Failed to load bot module:\n\n{e}\n\n"
            "Make sure all files are in the same folder as KalshiBot.exe.")
        return

    try:
        from dashboard_server import start_server
    except Exception as e:
        messagebox.showerror("Startup Error",
            f"Failed to load dashboard server:\n\n{e}")
        return

    mode = "PAPER" if paper_mode else "LIVE"
    print(f"[KalshiBot] {mode} mode | ${order_dollars}/trade | http://localhost:{PORT}")

    # Check port is free before starting Flask
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        result = s.connect_ex(("127.0.0.1", PORT))
        s.close()
        if result == 0:
            messagebox.showerror("Port In Use",
                f"Port {PORT} is already in use.\n\n"
                "Another instance of KalshiBot may already be running.\n"
                "Check your taskbar or Task Manager.")
            return
    except Exception:
        pass

    # Start bot thread
    try:
        bot_module.MAX_DAILY_LOSS = max_daily_loss
        bot_module.start_bot_thread(api_key, paper_mode)
    except Exception as e:
        messagebox.showerror("Bot Start Error", f"Failed to start bot:\n\n{e}")
        return

    # Start Flask in background thread
    def _run_flask():
        try:
            start_server(port=PORT)
        except Exception as e:
            messagebox.showerror("Server Error", f"Dashboard server crashed:\n\n{e}")

    threading.Thread(target=_run_flask, daemon=True, name="FlaskThread").start()

    # Open browser
    def _open():
        time.sleep(2.0)
        webbrowser.open(f"http://localhost:{PORT}")
    threading.Thread(target=_open, daemon=True).start()

    # Show small control window (keeps process alive, gives user a Quit button)
    _show_control_window(api_key, paper_mode, order_dollars, bot_module, max_daily_loss)


def _show_control_window(api_key, paper_mode, order_dollars, bot_module, max_daily_loss):
    """Small always-on-top control window — the only way to quit the bot cleanly."""
    root = tk.Tk()
    root.title("KalshiBot")
    root.configure(bg=BG)
    root.resizable(False, False)
    root.attributes("-topmost", True)

    # Position bottom-right corner of screen
    W, H = 340, 130
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f"{W}x{H}+{sw-W-20}+{sh-H-60}")

    # Prevent accidental close via X — must use Quit button
    def _on_close():
        pass  # do nothing — user must click Quit
    root.protocol("WM_DELETE_WINDOW", _on_close)

    # Header
    hdr = tk.Frame(root, bg=SURFACE, pady=8)
    hdr.pack(fill="x")
    tk.Label(hdr, text="● KALSHI BOT RUNNING", fg=GREEN, bg=SURFACE,
             font=("Courier New", 9, "bold")).pack(side="left", padx=12)

    mode_color = WARN if paper_mode else RED
    mode_text  = "PAPER" if paper_mode else "LIVE"
    tk.Label(hdr, text=mode_text, fg=mode_color, bg=SURFACE,
             font=("Courier New", 9, "bold")).pack(side="right", padx=12)

    # Dashboard link
    body = tk.Frame(root, bg=BG, pady=8, padx=14)
    body.pack(fill="x")

    def _open_browser():
        webbrowser.open(f"http://localhost:{PORT}")

    tk.Button(body, text=f"⬡  Open Dashboard  (localhost:{PORT})",
              command=_open_browser,
              bg=SURFACE, fg=ACCENT,
              font=("Courier New", 9), relief="flat", bd=0,
              padx=0, pady=6, cursor="hand2",
              activebackground=BG, activeforeground=ACCENT,
              anchor="w").pack(fill="x")

    # Buttons row
    btn_row = tk.Frame(root, bg=BG, padx=14, pady=6)
    btn_row.pack(fill="x")

    def _stop_bot():
        bot_module.stop_bot()
        stop_btn.config(text="● STOPPED", state="disabled", bg=SURFACE, fg=DIM)
        start_btn.config(state="normal")

    def _start_bot():
        bot_module.MAX_DAILY_LOSS = max_daily_loss
        bot_module.start_bot_thread(api_key, paper_mode)
        stop_btn.config(text="■  Stop Bot", state="normal", bg=SURFACE, fg=RED)
        start_btn.config(state="disabled")

    stop_btn = tk.Button(btn_row, text="■  Stop Bot",
                         command=_stop_bot,
                         bg=SURFACE, fg=RED,
                         font=("Courier New", 9, "bold"), relief="flat", bd=0,
                         padx=10, pady=5, cursor="hand2",
                         highlightthickness=1, highlightbackground=BORDER,
                         activebackground=BG, activeforeground=RED)
    stop_btn.pack(side="left", padx=(0, 6))

    start_btn = tk.Button(btn_row, text="▶  Start Bot",
                          command=_start_bot,
                          state="disabled",
                          bg=SURFACE, fg=DIM,
                          font=("Courier New", 9, "bold"), relief="flat", bd=0,
                          padx=10, pady=5, cursor="hand2",
                          highlightthickness=1, highlightbackground=BORDER,
                          activebackground=BG, activeforeground=GREEN)
    start_btn.pack(side="left")

    def _quit():
        bot_module.stop_bot()
        root.destroy()
        os._exit(0)   # clean exit — kills Flask + all threads

    tk.Button(btn_row, text="✕  Quit",
              command=_quit,
              bg=RED, fg="#000000",
              font=("Courier New", 9, "bold"), relief="flat", bd=0,
              padx=10, pady=5, cursor="hand2",
              activebackground="#cc0033", activeforeground="#000000").pack(side="right")

    root.mainloop()


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    cfg = load_config()
    SettingsWindow(cfg, on_launch=launch_bot)

if __name__ == "__main__":
    main()
