@echo off
setlocal EnableDelayedExpansion
title KalshiBot Builder

echo.
echo  ==========================================
echo    KalshiBot ^| Windows EXE Builder
echo  ==========================================
echo.

:: Check Python
echo [1/5] Checking Python...
py --version >nul 2>&1
if errorlevel 1 (
    python --version >nul 2>&1
    if errorlevel 1 (
        echo ERROR: Python not found. Download from python.org
        pause & exit /b 1
    )
    set PY=python
) else (
    set PY=py
)
for /f "tokens=*" %%v in ('!PY! --version 2^>^&1') do echo  Found: %%v
echo.

:: Install deps
echo [2/5] Installing dependencies...
!PY! -m pip install --quiet --upgrade requests flask flask-cors cryptography pyinstaller
if errorlevel 1 ( echo ERROR: pip failed & pause & exit /b 1 )
echo  Done.
echo.

:: Check files
echo [3/5] Checking source files...
set MISSING=0
for %%f in (launcher.py bot.py dashboard_server.py dashboard.html caching.wav) do (
    if not exist "%%f" ( echo  MISSING: %%f & set MISSING=1 ) else ( echo  OK: %%f )
)
if !MISSING!==1 ( echo. & echo ERROR: Put all files in the same folder as this script. & pause & exit /b 1 )
echo.

:: Build
echo [4/5] Building KalshiBot.exe (30-90 seconds)...
!PY! -m PyInstaller ^
    --onefile ^
    --windowed ^
    --name "KalshiBot" ^
    --add-data "dashboard.html;." ^
    --add-data "caching.wav;." ^
    --add-data "bot.py;." ^
    --add-data "dashboard_server.py;." ^
    --hidden-import flask ^
    --hidden-import flask_cors ^
    --hidden-import requests ^
    --hidden-import cryptography ^
    --hidden-import cryptography.hazmat.primitives ^
    --hidden-import cryptography.hazmat.backends ^
    --hidden-import cryptography.hazmat.backends.default_backend ^
    --hidden-import cryptography.hazmat.primitives.serialization ^
    --hidden-import cryptography.hazmat.primitives.hashes ^
    --hidden-import cryptography.hazmat.primitives.asymmetric ^
    --hidden-import cryptography.hazmat.primitives.asymmetric.padding ^
    --hidden-import tkinter ^
    --hidden-import tkinter.ttk ^
    --hidden-import tkinter.messagebox ^
    --hidden-import tkinter.filedialog ^
    --collect-all cryptography ^
    --clean ^
    launcher.py

if errorlevel 1 ( echo. & echo ERROR: Build failed. & pause & exit /b 1 )

:: Cleanup
echo.
echo [5/5] Cleaning up...
if exist build rmdir /s /q build >nul 2>&1
if exist KalshiBot.spec del KalshiBot.spec >nul 2>&1

echo.
echo  ==========================================
echo    BUILD SUCCESSFUL!
echo  ==========================================
echo.
echo  Your file: dist\KalshiBot.exe
echo.
echo  You can move KalshiBot.exe ANYWHERE - desktop,
echo  USB drive, send to a friend. It runs standalone.
echo.
echo  Config and trades save to:
echo  %%APPDATA%%\KalshiBot\
echo.
pause
