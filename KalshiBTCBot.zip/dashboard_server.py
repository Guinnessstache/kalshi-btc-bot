"""
Dashboard API server — serves bot state and trade history to the HTML dashboard.
Works both as a standalone script and when bundled inside a PyInstaller .exe.
"""

import sys
import os
from flask import Flask, jsonify, send_file, make_response
from flask_cors import CORS
import json
from pathlib import Path

# ── Resolve base dir (handles PyInstaller bundle) ────────────────────────────
if getattr(sys, 'frozen', False):
    BASE_DIR = sys._MEIPASS  # type: ignore
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DASHBOARD_HTML = os.path.join(BASE_DIR, "dashboard.html")

# Use APPDATA folder so trades.json persists regardless of where exe is run from
_app_data = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "KalshiBot")
os.makedirs(_app_data, exist_ok=True)
TRADES_FILE = os.path.join(_app_data, "trades.json")

app = Flask(__name__)
CORS(app)

try:
    from bot import get_state
except ImportError:
    def get_state():
        return {"status": "bot not running"}


def load_trades():
    p = Path(TRADES_FILE)
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception:
            return []
    return []


@app.route("/api/state")
def state():
    s = get_state()
    # Calculate session P&L from logged trades since session_start_id
    # This is accurate regardless of balance drift, manual trades, or delayed payouts
    try:
        start_id = s.get("session_start_id", 0)
        trades = load_trades()
        session_trades = [t for t in trades if t.get("id", 0) > start_id]
        s["trade_session_pnl"] = round(sum(t.get("pnl", 0) for t in session_trades), 2)
        s["trade_session_count"] = len(session_trades)
    except Exception:
        s["trade_session_pnl"] = None
    return jsonify(s)


@app.route("/api/trades")
def trades():
    return jsonify(load_trades())


@app.route("/api/stats")
def stats():
    import bot as bot_module
    all_trades = load_trades()
    # Only count trades since this session started (resets win rate on restart)
    start_id = get_state().get("session_start_id", 0)
    t = [x for x in all_trades if x.get("id", 0) > start_id]
    if not t:
        return jsonify({"total_trades": 0, "win_rate": 0, "total_pnl": 0,
                        "wins": 0, "losses": 0, "cash": 1000,
                        "all_time_trades": len(all_trades)})
    wins = [x for x in t if x.get("pnl", 0) > 0]
    pnl  = sum(x.get("pnl", 0) for x in t)
    return jsonify({
        "total_trades":    len(t),
        "wins":            len(wins),
        "losses":          len(t) - len(wins),
        "win_rate":        round(len(wins) / len(t) * 100, 1) if t else 0,
        "total_pnl":       round(pnl, 2),
        "cash":            t[-1].get("cash_after", 1000) if t else 1000,
        "all_time_trades": len(all_trades),
    })


@app.route("/api/set_strategy", methods=["POST"])
def set_strategy():
    import bot as bot_module
    from flask import request
    data = request.get_json()
    # Trigger / stop-loss (both naming conventions)
    trigger = data.get("trigger", data.get("trigger_price"))
    stop    = data.get("stop_loss", data.get("exit_price"))
    if trigger is not None:
        trigger = max(51, min(99, int(trigger)))
        bot_module.TRIGGER_PRICE = trigger
        bot_module.update_state(trigger_price=trigger)
    if stop is not None:
        stop = max(1, min(bot_module.TRIGGER_PRICE - 1, int(stop)))
        bot_module.EXIT_PRICE = stop
        bot_module.update_state(exit_price=stop)
    if "yes_only" in data:
        bot_module.YES_ONLY = bool(data["yes_only"])
        bot_module.update_state(yes_only=bot_module.YES_ONLY)
    if "scale_down" in data:
        bot_module.SCALE_DOWN_AFTER_LOSS = bool(data["scale_down"])
        bot_module.update_state(scale_down=bot_module.SCALE_DOWN_AFTER_LOSS)
    if "stop_cushion" in data:
        cushion = max(5, min(40, int(data["stop_cushion"])))
        bot_module.STOP_CUSHION = cushion
        bot_module.update_state(stop_cushion=cushion)
    if "trail_distance" in data:
        trail = max(3, min(30, int(data["trail_distance"])))
        bot_module.TRAIL_DISTANCE = trail
        bot_module.update_state(trail_distance=trail)
    if "velocity_exit" in data:
        vel = max(0, min(20, int(data["velocity_exit"])))
        bot_module.VELOCITY_EXIT = vel
        bot_module.update_state(velocity_exit=vel)
    if "stall_exit" in data:
        stall = max(0, min(600, int(data["stall_exit"])))
        bot_module.STALL_EXIT = stall
        bot_module.update_state(stall_exit=stall)
    # Persist to config file so settings survive restarts
    import json as _json
    _appdata = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "KalshiBot")
    _cfg_path = os.path.join(_appdata, "kalshi_config.json")
    try:
        _cfg = _json.loads(open(_cfg_path).read()) if os.path.exists(_cfg_path) else {}
        _cfg["trigger_price"] = bot_module.TRIGGER_PRICE
        _cfg["exit_price"]    = bot_module.EXIT_PRICE
        _cfg["yes_only"]      = bot_module.YES_ONLY
        _cfg["stop_cushion"]  = bot_module.STOP_CUSHION
        _cfg["velocity_exit"]  = bot_module.VELOCITY_EXIT
        _cfg["stall_exit"]     = bot_module.STALL_EXIT
        _cfg["trail_distance"] = bot_module.TRAIL_DISTANCE
        _cfg["scale_down"]    = bot_module.SCALE_DOWN_AFTER_LOSS
        open(_cfg_path, "w").write(_json.dumps(_cfg, indent=2))
    except Exception as _e:
        log.warning(f"Could not save config: {_e}")
    return jsonify({"trigger": bot_module.TRIGGER_PRICE,
                    "stop_loss": bot_module.EXIT_PRICE,
                    "stop_cushion": bot_module.STOP_CUSHION,
                    "trail_distance": bot_module.TRAIL_DISTANCE,
                    "velocity_exit": bot_module.VELOCITY_EXIT,
                    "stall_exit": bot_module.STALL_EXIT,
                    "yes_only": bot_module.YES_ONLY,
                    "scale_down": bot_module.SCALE_DOWN_AFTER_LOSS})


@app.route("/api/set_dollars", methods=["POST"])
def set_dollars():
    import bot as bot_module
    from flask import request
    data = request.get_json()
    dollars = float(data.get("dollars", 10))
    dollars = max(1.0, dollars)
    bot_module.ORDER_DOLLARS = dollars
    bot_module.update_state(order_dollars=dollars)
    return jsonify({"order_dollars": dollars})


@app.route("/api/stop", methods=["POST"])
def stop():
    import bot as bot_module
    bot_module.stop_bot()
    return jsonify({"status": "stopped"})


@app.route("/api/start", methods=["POST"])
def start():
    import bot as bot_module
    from flask import request
    data = request.get_json() or {}
    # Grab stored api_key/paper_mode from config file if available
    import json, os
    _appdata = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "KalshiBot")
    cfg_path = os.path.join(_appdata, "kalshi_config.json")
    cfg = {}
    try:
        if os.path.exists(cfg_path):
            cfg = json.loads(open(cfg_path).read())
    except Exception:
        pass
    paper_mode = cfg.get("paper_mode", True)
    if paper_mode:
        api_key = "PAPER_MODE_NO_KEY"
    else:
        key_id   = cfg.get("api_key", "")
        pem_path = cfg.get("pem_path", "")
        api_key  = f"{key_id}::{pem_path}" if key_id and pem_path else "PAPER_MODE_NO_KEY"
    # Don't start a second thread if already running
    state = bot_module.get_state()
    if state.get("running") and state.get("status") not in ("stopped",):
        return jsonify({"status": "already_running"})
    bot_module.start_bot_thread(api_key, paper_mode)
    return jsonify({"status": "started"})


@app.route("/api/balance")
def balance():
    """Fetch live balance directly — bypasses state cache."""
    import json, os
    _app_data = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "KalshiBot")
    cfg_path = os.path.join(_app_data, "kalshi_config.json")
    try:
        cfg = json.loads(open(cfg_path).read())
        if cfg.get("paper_mode", True):
            return jsonify({"balance": None, "mode": "paper"})
        import bot as bot_module
        state = bot_module.get_state()
        bal = state.get("live_balance")
        return jsonify({"balance": bal, "mode": "live"})
    except Exception as e:
        return jsonify({"balance": None, "error": str(e)})


@app.route("/api/set_loss_limit", methods=["POST"])
def set_loss_limit():
    import bot as bot_module
    from flask import request
    data    = request.get_json()
    limit   = float(data.get("limit", 0))
    limit   = max(0.0, limit)
    bot_module.MAX_DAILY_LOSS = limit
    bot_module.update_state(max_daily_loss=limit)
    return jsonify({"max_daily_loss": limit})


@app.route("/api/btc_price")
def btc_price():
    """Fetch real BTC/USD price from Coinbase — proxied through Flask to avoid CORS."""
    import urllib.request, json as _json
    sources = [
        ("https://api.coinbase.com/v2/prices/BTC-USD/spot",
         lambda d: float(d["data"]["amount"])),
        ("https://api.binance.us/api/v3/ticker/price?symbol=BTCUSDT",
         lambda d: float(d["price"])),
        ("https://api.kraken.com/0/public/Ticker?pair=XBTUSD",
         lambda d: float(d["result"]["XXBTZUSD"]["c"][0])),
    ]
    for url, extractor in sources:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "KalshiBot/1.0"})
            with urllib.request.urlopen(req, timeout=4) as resp:
                data = _json.loads(resp.read())
                price = round(extractor(data), 2)
                return jsonify({"price": price, "source": url.split("/")[2]})
        except Exception as e:
            log.warning(f"[BTC_PRICE] {url} failed: {e}")
    return jsonify({"price": None, "error": "All sources failed"}), 503


@app.route("/api/reset_session", methods=["POST"])
def reset_session():
    """Resync session_start_balance to current live balance — fixes P&L drift."""
    import bot as bot_module
    bal = bot_module.safe_call(bot_module.client.get_balance
          if hasattr(bot_module, 'client') and bot_module.client else lambda: None,
          timeout=5, default=None) if not bot_module.get_state().get("paper_mode") else None
    if bal is not None:
        bot_module.update_state(session_start_balance=bal, live_balance=bal)
        return jsonify({"session_start_balance": bal, "status": "reset"})
    return jsonify({"status": "no_balance", "error": "Could not fetch balance"}), 400


@app.route("/api/quit", methods=["POST"])
def quit_app():
    import bot as bot_module
    bot_module.stop_bot()
    # Shut down after a short delay so response can be sent
    def _exit():
        import time, os
        time.sleep(0.5)
        os._exit(0)
    threading.Thread(target=_exit, daemon=True).start()
    return jsonify({"status": "quitting"})


@app.route("/")
def index():
    return send_file(DASHBOARD_HTML)


def start_server(port=5050):
    app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    import threading
    from bot import run_bot

    api_key    = os.environ.get("KALSHI_API_KEY", "PAPER_MODE_NO_KEY")
    paper_mode = "--live" not in sys.argv

    bot_thread = threading.Thread(target=run_bot, args=(api_key, paper_mode), daemon=True)
    bot_thread.start()

    print(f"Bot running | Dashboard → http://localhost:5050")
    start_server()
