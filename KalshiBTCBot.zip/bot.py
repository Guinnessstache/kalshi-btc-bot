"""
Kalshi BTC 15-Min Trading Bot
Strategy: Enter UP or DOWN when price > 70¢, stop-loss at 40¢, exit 5s before window close
"""

import time
import json
import logging
import requests
import threading
from datetime import datetime, timezone
from pathlib import Path
import os

# ─── CONFIG ───────────────────────────────────────────────────────────────────

TRIGGER_PRICE   = 70    # cents — enter when YES price exceeds this
EXIT_PRICE      = 55    # cents — MINIMUM stop-loss price (used as fallback)
STOP_CUSHION    = 12    # cents below entry to set dynamic stop-loss
TRAIL_DISTANCE  = 8     # cents — once price rises this much above entry, trail the stop up
VELOCITY_EXIT   = 8     # cents — if price drops this much in one poll, exit immediately
STALL_EXIT      = 180   # seconds — exit if price hasn't moved above entry after this long
TRIGGER_MINUTE  = 14    # enter only when ≤14 minutes remain in the 15-min window
MAX_RETRIES     = 4     # order placement retries
ORDER_DOLLARS   = 10.00 # dollars to risk per trade — bot calculates contracts automatically
MAX_DAILY_LOSS  = 20.00 # bot auto-stops if balance drops this many dollars from session start
YES_ONLY             = True  # only enter YES/UP positions — skip NO/DOWN
SCALE_DOWN_AFTER_LOSS = True  # halve trade size after stop-loss, restore after win

KALSHI_BASE_URL = "https://api.elections.kalshi.com/trade-api/v2"
# BTC 15-min market ticker prefix — bot will auto-discover current active market
BTC_MARKET_PREFIX = "KXBTC15M"

# Store trades in APPDATA so they persist and match what dashboard_server reads
import os as _os
_APP_DATA = _os.path.join(_os.environ.get("APPDATA", _os.path.expanduser("~")), "KalshiBot")
_os.makedirs(_APP_DATA, exist_ok=True)
LOG_FILE  = _os.path.join(_APP_DATA, "trades.json")
POLL_INTERVAL = 0.5   # seconds between price polls

# ─── DOLLAR-BASED SIZING ──────────────────────────────────────────────────────

def dollars_to_contracts(dollars: float, price_cents: int) -> int:
    """
    Convert a dollar budget into a contract count.
    Each contract costs price_cents / 100 dollars.
    Mirrors the HUD's FILL DOLLARS approach — you set dollars, we calc contracts.
    Always rounds down so you never exceed your budget. Minimum 1 contract.
    """
    if price_cents <= 0:
        return 1
    cost_per_contract = price_cents / 100.0
    count = int(dollars / cost_per_contract)
    return max(1, count)

# ─── SOUND ────────────────────────────────────────────────────────────────────

def _play_caching():
    """Play the ca-ching sound in a background thread (non-blocking)."""
    import threading
    def _play():
        try:
            import sys, os
            # Find the WAV file — works both in source and PyInstaller bundle
            if getattr(sys, 'frozen', False):
                base = sys._MEIPASS
            else:
                base = os.path.dirname(os.path.abspath(__file__))
            wav_path = os.path.join(base, "caching.wav")
            if not os.path.exists(wav_path):
                return
            # Use winsound on Windows (built-in, no deps)
            import winsound
            winsound.PlaySound(wav_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        except Exception:
            pass  # Sound is non-critical — never crash the bot over it
    threading.Thread(target=_play, daemon=True).start()

# ─── LOGGING ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("KalshiBot")

# ─── TRADE JOURNAL ────────────────────────────────────────────────────────────

class TradeJournal:
    def __init__(self, path=LOG_FILE):
        self.path = Path(path)
        self.lock = threading.Lock()
        # Never overwrite existing data — only create if missing
        if not self.path.exists():
            self._write([])
        else:
            # Validate existing file — repair if corrupted
            try:
                existing = json.loads(self.path.read_text())
                if not isinstance(existing, list):
                    raise ValueError("Not a list")
                log.info(f"📓 Trade journal loaded: {len(existing)} existing trades")
            except Exception as e:
                log.warning(f"📓 Trade journal corrupted ({e}) — backing up and starting fresh")
                backup = str(self.path) + ".bak"
                try:
                    self.path.rename(backup)
                except Exception:
                    pass
                self._write([])

    def _read(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def _write(self, data):
        # Atomic write — write to temp file then rename to prevent corruption
        tmp = str(self.path) + ".tmp"
        try:
            Path(tmp).write_text(json.dumps(data, indent=2), encoding="utf-8")
            Path(tmp).replace(self.path)
        except Exception as e:
            log.error(f"📓 Failed to write trades: {e}")

    def log_trade(self, trade: dict):
        with self.lock:
            trades = self._read()
            # Assign sequential ID based on actual count
            trade["id"] = len(trades) + 1
            trades.append(trade)
            self._write(trades)
            log.info(f"📓 Trade #{trade['id']} logged: {trade.get('side')} P&L={trade.get('pnl')}")

    def get_all(self):
        return self._read()

journal = TradeJournal()

# ─── KALSHI API CLIENT ────────────────────────────────────────────────────────

class KalshiClient:
    """
    Authenticates using RSA-PSS signatures as required by Kalshi API v2.
    Signing format (from docs): timestamp_ms + METHOD + path_without_query
    Headers: KALSHI-ACCESS-KEY, KALSHI-ACCESS-TIMESTAMP, KALSHI-ACCESS-SIGNATURE
    """

    def __init__(self, api_key_id: str, private_key_path: str):
        import base64
        from cryptography.hazmat.primitives import serialization, hashes
        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.backends import default_backend
        import datetime

        self.api_key_id    = api_key_id
        self.base64        = base64
        self.hashes        = hashes
        self.padding       = padding
        self.datetime      = datetime

        # Load private key - supports PKCS#1 and PKCS#8 formats
        with open(private_key_path, "rb") as kf:
            key_data = kf.read()

        loaded = False
        try:
            self.private_key = serialization.load_pem_private_key(
                key_data, password=None, backend=default_backend()
            )
            loaded = True
        except Exception:
            pass

        if not loaded:
            try:
                import base64 as _b64
                _lines = key_data.decode("utf-8").strip().splitlines()
                _b64body = "".join(l for l in _lines if not l.startswith("-----"))
                _der = _b64.b64decode(_b64body)
                from cryptography.hazmat.primitives.serialization import load_der_private_key
                self.private_key = load_der_private_key(
                    _der, password=None, backend=default_backend()
                )
                loaded = True
            except Exception as _e:
                raise ValueError("Could not load private key: " + str(_e))

        log.info("[AUTH] Private key loaded: " + type(self.private_key).__name__)

        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})

    def _sign(self, method: str, path: str) -> dict:
        """Generate RSA-PSS auth headers.
        Kalshi requires signing the FULL path from root: /trade-api/v2/portfolio/balance
        NOT just /portfolio/balance
        """
        current_time = self.datetime.datetime.now()
        ts_ms = str(int(current_time.timestamp() * 1000))
        # Full path = /trade-api/v2 + endpoint (strip query params)
        full_path = ("/trade-api/v2" + path).split("?")[0]
        msg_bytes = (ts_ms + method.upper() + full_path).encode("utf-8")

        sig_bytes = self.private_key.sign(
            msg_bytes,
            self.padding.PSS(
                mgf=self.padding.MGF1(self.hashes.SHA256()),
                salt_length=self.padding.PSS.DIGEST_LENGTH,
            ),
            self.hashes.SHA256(),
        )

        sig_b64 = self.base64.b64encode(sig_bytes).decode("utf-8")
        return {
            "KALSHI-ACCESS-KEY":       self.api_key_id,
            "KALSHI-ACCESS-TIMESTAMP": ts_ms,
            "KALSHI-ACCESS-SIGNATURE": sig_b64,
        }

    def _get(self, path, params=None):
        url     = f"{KALSHI_BASE_URL}{path}"
        headers = self._sign("GET", path)
        r = self.session.get(url, params=params, headers=headers, timeout=10)
        if r.status_code == 401:
            log.error(f"[AUTH 401] Response body: {r.text}")
        r.raise_for_status()
        return r.json()

    def _post(self, path, body):
        url     = f"{KALSHI_BASE_URL}{path}"
        headers = self._sign("POST", path)
        r = self.session.post(url, json=body, headers=headers, timeout=5)
        if not r.ok:
            log.error(f"[POST {r.status_code}] {path} -> {r.text[:300]}")
        r.raise_for_status()
        return r.json()

    def get_markets(self, series_ticker=BTC_MARKET_PREFIX):
        """Fetch active BTC 15-min markets, filtered to ones with real liquidity."""
        import datetime as dt
        data = self._get("/markets", params={
            "series_ticker": series_ticker,
            "status": "open",
            "limit": 20,
        })
        markets = data.get("markets", [])
        log.info(f"[MARKET] {len(markets)} open markets for {series_ticker}")

        now = dt.datetime.now(dt.timezone.utc)
        good = []
        for m in markets:
            ticker = m.get("ticker", "")
            close_str = m.get("close_time", "")
            # Parse close time
            try:
                close_dt = dt.datetime.fromisoformat(close_str.replace("Z", "+00:00"))
                mins_left = (close_dt - now).total_seconds() / 60
            except Exception:
                mins_left = 999

            # Check yes_ask price — skip markets that have already resolved (>95c or <5c)
            try:
                yes_ask = float(m.get("yes_ask_dollars", 0.5)) * 100
            except Exception:
                yes_ask = 50

            log.info(f"[MARKET]   {ticker} close={close_str} mins_left={mins_left:.1f} yes_ask={yes_ask:.0f}c")

            # Skip if basically resolved (price >90c or <10c) or already closing (<2 min)
            if yes_ask > 90 or yes_ask < 10:
                log.info(f"[MARKET]   -> SKIP (resolved price {yes_ask:.0f}c)")
                continue
            if mins_left < 2:
                log.info(f"[MARKET]   -> SKIP (closing in {mins_left:.1f} min)")
                continue

            good.append(m)

        if good:
            log.info(f"[MARKET] Using: {good[0].get('ticker')}")
        else:
            log.warning("[MARKET] No suitable markets found — all resolved or closing")
        return good

    def get_market(self, ticker):
        """Get prices from market endpoint (yes_ask_dollars / no_ask_dollars fields)."""
        # Use market endpoint directly — simpler and more reliable than orderbook
        data = self._get(f"/markets/{ticker}")
        mkt  = data.get("market", {})

        def to_cents(field):
            v = mkt.get(field)
            try:
                return round(float(v) * 100) if v else None
            except Exception:
                return None

        yes_ask = to_cents("yes_ask_dollars")
        no_ask  = to_cents("no_ask_dollars")
        yes_bid = to_cents("yes_bid_dollars")
        no_bid  = to_cents("no_bid_dollars")

        # Derive missing asks from opposite bids (binary market relationship)
        if yes_ask is None and no_bid is not None:
            yes_ask = 100 - no_bid
        if no_ask is None and yes_bid is not None:
            no_ask = 100 - yes_bid

        yes_ask = yes_ask or 50
        no_ask  = no_ask  or 50

        log.info(f"[PRICE] {ticker}: YES={yes_ask}c NO={no_ask}c")
        return {"yes_ask": yes_ask, "no_ask": no_ask, "ticker": ticker}

    def place_order(self, ticker, side, count, price_cents, action="buy"):
        """
        Places an IOC limit order.
        action: "buy" to open, "sell" to close an existing position.
        Kalshi requires ONLY one price field (yes_price).
        For buys we add 2c buffer to cross the spread.
        For sells we subtract 2c to cross the spread the other way.
        """
        import uuid
        if action == "buy":
            buffered  = min(99, price_cents + 2)
        else:
            buffered  = max(1, price_cents - 2)
        yes_price = buffered if side == "yes" else (100 - buffered)
        body = {
            "ticker":          ticker,
            "action":          action,
            "side":            side,
            "count":           count,
            "type":            "limit",
            "yes_price":       yes_price,
            "time_in_force":   "immediate_or_cancel",
            "client_order_id": str(uuid.uuid4()),
        }
        log.info(f"[ORDER] {action.upper()} {side.upper()} x{count} yes_price={yes_price}c IOC on {ticker}")
        resp = self._post("/portfolio/orders", body)
        log.info(f"[ORDER] Response: {resp}")
        return resp

    def get_order(self, order_id):
        return self._get(f"/portfolio/orders/{order_id}")

    def get_positions(self, ticker=None):
        params = {}
        if ticker:
            params["ticker"] = ticker
        data = self._get("/portfolio/positions", params=params)
        return data.get("market_positions", [])

    def has_open_position(self, ticker):
        """Returns True if we have a non-zero position on this ticker."""
        try:
            positions = self.get_positions(ticker)
            for p in positions:
                # position field is int, position_fp is string like "2.00"
                pos_int = p.get("position", 0) or 0
                pos_fp  = float(p.get("position_fp", "0") or "0")
                if pos_int != 0 or pos_fp != 0:
                    log.info(f"[POS] {ticker}: position={pos_int} position_fp={pos_fp}")
                    return True
            return False
        except Exception as e:
            log.error(f"[POS] Error checking position: {e}")
            return False

    def get_open_orders(self, ticker):
        data = self._get("/portfolio/orders", params={"ticker": ticker, "status": "resting"})
        return data.get("orders", [])

    def cancel_order(self, order_id):
        return self._post(f"/portfolio/orders/{order_id}/decrease", {"reduce_by": 9999})

    def get_balance(self):
        """Returns available balance in dollars."""
        try:
            data = self._get("/portfolio/balance")
            log.info(f"[BALANCE] Raw: {data}")
            # Try cents integer field first, then dollar string fields
            if "balance" in data and isinstance(data["balance"], (int, float)):
                return round(data["balance"] / 100, 2)
            # Some responses nest under "available_balance" as dollar string
            for field in ["available_balance_dollars", "balance_dollars"]:
                if field in data:
                    return round(float(data[field]), 2)
            return None
        except Exception as e:
            log.error(f"[BALANCE] Failed: {e}")
            return None

# ─── PAPER TRADING ENGINE ─────────────────────────────────────────────────────

class PaperEngine:
    """Simulates order fills and tracks paper P&L"""
    def __init__(self):
        self.position = None   # {'side': 'yes'/'no', 'entry_price': int, 'count': int, 'ticker': str, 'entry_time': str}
        self.cash = 1000       # starting paper balance in dollars
        self.trades = []

    def has_position(self):
        return self.position is not None

    def open_position(self, ticker, side, count, price_cents):
        cost = (price_cents / 100) * count
        self.position = {
            "ticker": ticker,
            "side": side,
            "entry_price": price_cents,
            "count": count,
            "entry_time": datetime.now(timezone.utc).isoformat(),
        }
        self.cash -= cost
        log.info(f"[PAPER] Opened {side.upper()} x{count} @ {price_cents}¢  |  Cash: ${self.cash:.2f}")
        return True

    def close_position(self, exit_price_cents, reason):
        if not self.position:
            return
        pos = self.position
        pnl_per = exit_price_cents - pos["entry_price"]
        total_pnl = (pnl_per / 100) * pos["count"]
        self.cash += (exit_price_cents / 100) * pos["count"]

        trade_record = {
            "id": len(self.trades) + 1,
            "ticker": pos["ticker"],
            "side": pos["side"],
            "entry_price": pos["entry_price"],
            "exit_price": exit_price_cents,
            "count": pos["count"],
            "pnl": round(total_pnl, 4),
            "reason": reason,
            "entry_time": pos["entry_time"],
            "exit_time": datetime.now(timezone.utc).isoformat(),
            "cash_after": round(self.cash, 2),
        }
        self.trades.append(trade_record)
        journal.log_trade(trade_record)

        emoji = "✅" if total_pnl >= 0 else "❌"
        log.info(f"[PAPER] {emoji} Closed {pos['side'].upper()} @ {exit_price_cents}¢  PnL: ${total_pnl:+.2f}  Reason: {reason}")
        self.position = None
        return trade_record

    def stats(self):
        if not self.trades:
            return {"total_trades": 0, "win_rate": 0, "total_pnl": 0, "cash": self.cash}
        wins = [t for t in self.trades if t["pnl"] > 0]
        total_pnl = sum(t["pnl"] for t in self.trades)
        return {
            "total_trades": len(self.trades),
            "wins": len(wins),
            "losses": len(self.trades) - len(wins),
            "win_rate": round(len(wins) / len(self.trades) * 100, 1),
            "total_pnl": round(total_pnl, 2),
            "cash": round(self.cash, 2),
        }

# ─── TIME HELPERS ─────────────────────────────────────────────────────────────

def minutes_remaining_in_window(window_minutes=15):
    """Minutes remaining until next 15-min boundary"""
    now = datetime.now(timezone.utc)
    minute = now.minute
    second = now.second
    elapsed_in_window = minute % window_minutes * 60 + second
    window_seconds = window_minutes * 60
    remaining_seconds = window_seconds - elapsed_in_window
    return remaining_seconds / 60

def is_5sec_before_window_close(window_minutes=15):
    now = datetime.now(timezone.utc)
    minute = now.minute
    second = now.second
    remaining_seconds = (window_minutes - minute % window_minutes) * 60 - second
    return remaining_seconds <= 5

def in_trigger_window():
    """True when ≤ TRIGGER_MINUTE minutes remain"""
    return minutes_remaining_in_window() <= TRIGGER_MINUTE

# ─── STATE BROADCAST (for dashboard) ─────────────────────────────────────────

_state = {
    "status": "stopped",
    "ticker": None,
    "up_price": 0,
    "down_price": 0,
    "position": None,
    "order_dollars": ORDER_DOLLARS,
    "minutes_remaining": 0,
    "last_log": "",
    "paper_stats": {},
    "session": 0,
    "running": True,   # set True at init since bot starts immediately
    "paper_mode": True,     # updated at bot start
    "live_balance":       None,
    "session_start_balance": None,  # balance when bot started this run
    "max_daily_loss":     MAX_DAILY_LOSS,
    "daily_loss_hit":     False,
    "session_start_id":   0,    # trade ID when this run started — for per-session stats
    "yes_only":           False,
    "scale_down":         False,
    "stop_cushion":       STOP_CUSHION,
    "trail_distance":     8,
    "velocity_exit":      8,
    "stall_exit":         180,
    "current_dollars":    0,  # set properly in run_bot after ORDER_DOLLARS is loaded
}
_state_lock = threading.Lock()

# ── Position guard — ensures only ONE trade is ever open at a time ────────────
# This is the single source of truth. Even if the bot loop runs fast or a race
# condition occurs between price check and order placement, this lock prevents
# a second trade from opening while one is already active.
_position_lock = threading.Lock()
_has_active_position = False

def _acquire_position() -> bool:
    """Try to claim the active position slot. Returns True if successful."""
    global _has_active_position
    with _position_lock:
        if _has_active_position:
            return False
        _has_active_position = True
        return True

def _release_position():
    """Release the active position slot."""
    global _has_active_position
    with _position_lock:
        _has_active_position = False

def _check_has_position() -> bool:
    with _position_lock:
        return _has_active_position

# Bot control
_bot_stop_event = threading.Event()

def stop_bot():
    _bot_stop_event.set()
    _release_position()   # clear any lingering lock on manual stop
    update_state(status="stopped", running=False, position=None)

def start_bot_thread(api_key, paper_mode):
    _bot_stop_event.clear()
    update_state(running=True, status="starting", order_dollars=ORDER_DOLLARS)

    def _run_with_recovery():
        consecutive_crashes = 0
        while not _bot_stop_event.is_set():
            try:
                run_bot(api_key, paper_mode)
            except Exception as e:
                if _bot_stop_event.is_set():
                    break
                consecutive_crashes += 1
                wait = min(30, consecutive_crashes * 5)
                log.error(f"[CRASH] Bot thread crashed: {e} — restarting in {wait}s (crash #{consecutive_crashes})")
                update_state(status=f"crashed — restarting in {wait}s", last_log=f"❗ Bot crashed: {e} — restarting in {wait}s")
                import traceback
                log.error(traceback.format_exc())
                time.sleep(wait)
                if consecutive_crashes >= 10:
                    log.error("[CRASH] Too many crashes — stopping bot")
                    update_state(status="stopped", running=False,
                                 last_log="❗ Bot stopped after 10 crashes — click Start to retry")
                    break
            else:
                # Clean exit (stop_bot() called)
                break

    t = threading.Thread(target=_run_with_recovery, daemon=True, name="BotThread")
    t.start()
    return t

def update_state(**kwargs):
    with _state_lock:
        _state.update(kwargs)

def get_state():
    with _state_lock:
        return dict(_state)

def bot_log(msg):
    log.info(msg)
    update_state(last_log=msg)

# ─── DYNAMIC STOP-LOSS ───────────────────────────────────────────────────────

def dynamic_stop(entry_price, cushion=None):
    """Calculate stop-loss as entry_price minus cushion.
    Uses STOP_CUSHION from state (editable from dashboard).
    Floor at 1, ceiling never above entry-5."""
    c = cushion or get_state().get("stop_cushion", STOP_CUSHION)
    stop = entry_price - int(c)
    return max(1, min(entry_price - 5, stop))

# ─── SAFE CALL (thread-timeout wrapper) ──────────────────────────────────────

def safe_call(fn, timeout=6, default=None):
    """Run fn() in a thread with a hard timeout. Returns default if it hangs."""
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
        future = ex.submit(fn)
        try:
            return future.result(timeout=timeout)
        except concurrent.futures.TimeoutError:
            log.error(f"[TIMEOUT] {fn.__name__ if hasattr(fn,'__name__') else fn} timed out after {timeout}s")
            return default
        except Exception as e:
            log.error(f"[SAFE_CALL] {e}")
            return default

# ─── WATCHDOG ─────────────────────────────────────────────────────────────────

_last_price_update = [time.time()]  # use list so it's mutable in nested scope

def _record_price_update():
    _last_price_update[0] = time.time()

def _start_watchdog():
    """Warns if prices haven't updated in >60 seconds while bot is running."""
    import threading
    def _watch():
        while True:
            time.sleep(30)
            state = get_state()
            if not state.get("running"):
                continue
            # Don't fire during states where no prices are expected
            if state.get("status") in ("waiting_close", "resolving", "stopped",
                                       "waiting_window", "starting"):
                _last_price_update[0] = time.time()  # reset timer
                continue
            elapsed = time.time() - _last_price_update[0]
            if elapsed > 90:  # more lenient threshold
                log.warning(f"[WATCHDOG] Prices not updated for {elapsed:.0f}s — possible stall")
                bot_log(f"⚠️ Price updates stalled ({elapsed:.0f}s) — bot may be frozen")
    threading.Thread(target=_watch, daemon=True, name="Watchdog").start()

# ─── MAIN BOT LOOP ────────────────────────────────────────────────────────────

def run_bot(api_key: str, paper_mode: bool = True):
    # api_key is "KEY_ID::path/to/private.pem" for live mode
    if not paper_mode:
        parts = api_key.split("::", 1)
        if len(parts) != 2:
            bot_log("❌ Live mode requires API Key ID and private key path separated by '::'")
            return
        client = KalshiClient(api_key_id=parts[0], private_key_path=parts[1])
    else:
        client = None
    paper  = PaperEngine() if paper_mode else None
    session_count = 0
    current_trade_dollars = ORDER_DOLLARS  # may scale down after stop-losses
    update_state(current_dollars=ORDER_DOLLARS)  # sync display immediately

    # Sync current state at start
    # Set session_start_id so win rate resets each time bot starts
    existing_trades = journal.get_all()
    session_start_id = existing_trades[-1]["id"] if existing_trades else 0
    update_state(order_dollars=ORDER_DOLLARS, running=True,
                 paper_mode=paper_mode, ticker=None, live_balance=None,
                 max_daily_loss=MAX_DAILY_LOSS, daily_loss_hit=False,
                 trigger_price=TRIGGER_PRICE, exit_price=EXIT_PRICE,
                 session_start_id=session_start_id)
    log.info(f"[CONFIG] session_start_id={session_start_id} — win rate resets here")

    mode_label = "📄 PAPER" if paper_mode else "💰 LIVE"
    bot_log(f"Bot started — {mode_label} mode")
    _start_watchdog()

    # Fetch fresh balance at start — this is the true session baseline
    start_balance = None
    if not paper_mode and client:
        bal = safe_call(client.get_balance, timeout=5, default=None)
        if bal is not None:
            start_balance = bal
            update_state(live_balance=bal, session_start_balance=bal)
            log.info(f"[SESSION] Start balance: ${bal:.2f} — session P&L resets from here")
            limit_str = f" | Max loss: ${MAX_DAILY_LOSS:.2f}" if MAX_DAILY_LOSS > 0 else " | No loss limit set"
            bot_log(f"💰 Account balance: ${bal:.2f}{limit_str}")
        else:
            bot_log("⚠️  Could not fetch balance — check activity log for [BALANCE] errors")

    while not _bot_stop_event.is_set():
        try:
            session_count += 1
            update_state(status="waiting_window", session=session_count)

            # Refresh balance and check daily loss limit
            if not paper_mode and client:
                bal = safe_call(client.get_balance, timeout=5, default=None)
                if bal is not None:
                    state = get_state()
                    update_state(live_balance=bal)
                    # If session_start_balance was never properly set, fix it now
                    if not state.get("session_start_balance"):
                        update_state(session_start_balance=bal)
                        start_balance = bal
                    # Check max daily loss (skip if 0 = disabled)
                    if start_balance is not None and MAX_DAILY_LOSS > 0:
                        loss = start_balance - bal
                        if loss >= MAX_DAILY_LOSS:
                            bot_log(f"🛑 MAX DAILY LOSS HIT — lost ${loss:.2f} (limit ${MAX_DAILY_LOSS:.2f}). Bot stopping.")
                            update_state(daily_loss_hit=True, status="stopped")
                            stop_bot()
                            return
                        remaining = MAX_DAILY_LOSS - loss
                        bot_log(f"💰 Balance: ${bal:.2f} | Loss: ${loss:.2f} | Remaining: ${remaining:.2f}")
            bot_log(f"Session #{session_count} — Waiting for trigger window (≤{TRIGGER_MINUTE} min remaining)")

            # ── Find active BTC market ─────────────────────────────────────
            ticker = None
            if not paper_mode:
                markets = safe_call(client.get_markets, timeout=6, default=[])
                if not markets:
                    # Between windows — poll faster until next market opens
                    bot_log("⏳ Between windows — waiting for next market to open...")
                    _record_price_update()
                    for _ in range(10):
                        if _bot_stop_event.is_set():
                            break
                        time.sleep(3)
                        _record_price_update()
                        markets = safe_call(client.get_markets, timeout=6, default=[])
                        if markets:
                            break
                    if not markets:
                        continue
                ticker = markets[0]["ticker"]
            else:
                # Paper mode: use a placeholder ticker
                ticker = f"{BTC_MARKET_PREFIX}-PAPER-{datetime.now(timezone.utc).strftime('%H%M')}"

            update_state(ticker=ticker)

            # ── Wait for trigger window — poll prices continuously ─────────
            while not in_trigger_window():
                mins = minutes_remaining_in_window()
                update_state(minutes_remaining=round(mins, 1), status="waiting_window")
                # Keep prices updating even while waiting
                if not paper_mode and ticker:
                    try:
                        mkt = safe_call(lambda: client.get_market(ticker), timeout=5, default={})
                        up   = mkt.get("yes_ask", 50)
                        down = mkt.get("no_ask",  50)
                        update_state(up_price=up, down_price=down)
                        _record_price_update()
                    except Exception:
                        pass
                time.sleep(POLL_INTERVAL)

            bot_log(f"⏱  Trigger window active! Monitoring prices >{TRIGGER_PRICE}¢")
            update_state(status="monitoring")
            _record_price_update()  # reset watchdog timer when monitoring starts

            # ── Monitor prices until trigger or window-end ─────────────────
            up_price   = 0
            down_price = 0

            while True:
                if is_5sec_before_window_close():
                    bot_log("⏰ 5s before window close — no entry this session")
                    break

                if paper_mode:
                    # Simulate prices (replace with real feed if desired)
                    import random
                    up_price   = random.randint(30, 85)
                    down_price = 100 - up_price + random.randint(-3, 3)
                    down_price = max(5, min(95, down_price))
                else:
                    mkt = safe_call(lambda: client.get_market(ticker), timeout=5, default={})
                    up_price   = mkt.get("yes_ask", 50)
                    down_price = mkt.get("no_ask",  50)
                    _record_price_update()

                update_state(up_price=up_price, down_price=down_price,
                             minutes_remaining=round(minutes_remaining_in_window(), 1))

                # Guard: never open a second trade while one is active
                if _check_has_position():
                    bot_log("⚠️  Position already active — skipping entry this session")
                    break

                # Read live trigger/exit from state (allows dashboard updates)
                live_trigger = get_state().get("trigger_price", TRIGGER_PRICE)
                live_exit    = get_state().get("exit_price",    EXIT_PRICE)

                if up_price > live_trigger:
                    if not _acquire_position():
                        bot_log("⚠️  Position claimed by another thread — skipping")
                        break
                    bot_log(f"🚀 UP triggered @ {up_price}¢ (trigger={live_trigger}¢) — entering YES (${current_trade_dollars:.2f})")
                    was_sl = _enter_and_manage("yes", up_price, ticker, client, paper, paper_mode,
                                               trade_dollars=current_trade_dollars)
                    if SCALE_DOWN_AFTER_LOSS or get_state().get("scale_down"):
                        if was_sl:
                            current_trade_dollars = max(1.0, ORDER_DOLLARS / 2)
                            bot_log(f"📉 Stop-loss — scaling down to ${current_trade_dollars:.2f}/trade")
                        else:
                            current_trade_dollars = ORDER_DOLLARS
                        update_state(current_dollars=current_trade_dollars)
                    break

                elif down_price > live_trigger:
                    live_yes_only = get_state().get("yes_only", YES_ONLY)
                    if live_yes_only:
                        bot_log(f"⏭  NO signal @ {down_price}¢ skipped — YES-only mode active")
                    else:
                        if not _acquire_position():
                            bot_log("⚠️  Position claimed by another thread — skipping")
                            break
                        bot_log(f"📉 DOWN triggered @ {down_price}¢ (trigger={live_trigger}¢) — entering NO (${current_trade_dollars:.2f})")
                        was_sl = _enter_and_manage("no", down_price, ticker, client, paper, paper_mode,
                                                   trade_dollars=current_trade_dollars)
                        if SCALE_DOWN_AFTER_LOSS or get_state().get("scale_down"):
                            if was_sl:
                                current_trade_dollars = max(1.0, ORDER_DOLLARS / 2)
                                bot_log(f"📉 Stop-loss — scaling down to ${current_trade_dollars:.2f}/trade")
                            else:
                                current_trade_dollars = ORDER_DOLLARS
                            update_state(current_dollars=current_trade_dollars)
                        break

                time.sleep(POLL_INTERVAL)

            if paper_mode:
                update_state(paper_stats=paper.stats())

            # ── Wait for session to fully close ────────────────────────────
            bot_log("Waiting for session to close...")
            update_state(status="waiting_close")
            # Hard timeout of 20 minutes max — prevents infinite loop
            deadline = time.time() + 20 * 60
            while minutes_remaining_in_window() > 0.1:
                if _bot_stop_event.is_set():
                    break
                if time.time() > deadline:
                    bot_log("⚠️ Session close timeout — forcing next session")
                    break
                time.sleep(1)
                update_state(minutes_remaining=round(minutes_remaining_in_window(), 1))
            time.sleep(2)

        except KeyboardInterrupt:
            bot_log("Bot stopped by user")
            break
        except Exception as e:
            import traceback
            bot_log(f"❗ Session error: {e}")
            log.error(f"[SESSION ERROR] {traceback.format_exc()}")
            time.sleep(5)


def _enter_and_manage(side, entry_price, ticker, client, paper, paper_mode,
                      live_exit=None, trade_dollars=None):
    """Place order, confirm fill, then manage stop-loss. Uses trade_dollars for sizing."""
    if trade_dollars is None:
        trade_dollars = ORDER_DOLLARS
    filled = False
    contracts = dollars_to_contracts(trade_dollars, entry_price)
    bot_log(f"  💵 ${trade_dollars:.2f} @ {entry_price}¢ = {contracts} contract(s)")

    for attempt in range(1, MAX_RETRIES + 1):
        # Refresh price from market on each attempt — it may have moved
        if not paper_mode and attempt > 1:
            try:
                fresh = safe_call(lambda: client.get_market(ticker), timeout=5, default={})
                fresh_price = fresh.get("yes_ask" if side == "yes" else "no_ask", entry_price)
                if fresh_price and fresh_price != entry_price:
                    bot_log(f"  Price updated: {entry_price}¢ → {fresh_price}¢")
                    entry_price = fresh_price
                    contracts = dollars_to_contracts(trade_dollars, entry_price)
            except Exception:
                pass

        bot_log(f"  Attempt {attempt}/{MAX_RETRIES} — placing {side.upper()} order @ {entry_price}¢")

        if paper_mode:
            filled = paper.open_position(ticker, side, contracts, entry_price)
        else:
            try:
                price_for_order = entry_price  # capture for lambda
                resp = safe_call(lambda: client.place_order(ticker, side, contracts, price_for_order), timeout=8, default={})
                order = resp.get("order", {})
                status = order.get("status", "")
                fill_count = float(order.get("fill_count_fp", "0") or order.get("fill_count", 0) or 0)
                bot_log(f"  [ORDER] status={status} fill={fill_count} resp={resp}")
                filled = fill_count > 0 or status == "filled"
            except Exception as e:
                bot_log(f"  Order error: {e}")

        if filled:
            bot_log(f"  ✅ {side.upper()} position confirmed")
            entry_time = datetime.now(timezone.utc).isoformat()
            update_state(position={"side": side, "entry_price": entry_price,
                                   "contracts": contracts, "ticker": ticker,
                                   "entry_time": entry_time})
            _play_caching()
            break
        else:
            bot_log("  ⚠️  Not filled — retrying...")
            time.sleep(1)

    if not filled:
        bot_log("❌ Failed to fill after 4 retries — skipping session")
        _release_position()   # release lock so next session can try
        return

    # ── Manage position: stop-loss or expiry ──────────────────────────────
    update_state(status="in_position")

    while not is_5sec_before_window_close():
        if paper_mode:
            import random
            current_price = entry_price + random.randint(-15, 15)
            current_price = max(2, min(98, current_price))
        else:
            try:
                mkt = safe_call(lambda: client.get_market(ticker), timeout=5, default={})
                current_price = mkt.get("yes_ask" if side == "yes" else "no_ask", entry_price)
                _record_price_update()
            except Exception as e:
                log.error(f"[PRICE] Failed to fetch price: {e}")
                current_price = entry_price  # keep last known price

        update_state(
            up_price          = current_price if side == "yes" else (100 - current_price),
            down_price        = current_price if side == "no"  else (100 - current_price),
            minutes_remaining = round(minutes_remaining_in_window(), 1),
        )

        effective_exit = live_exit if live_exit is not None else EXIT_PRICE
        if current_price < effective_exit:
            # Double-check before closing (mirrors DoubleExitCheck in original)
            time.sleep(0.5)
            if current_price < effective_exit and current_price > 2:
                bot_log(f"🛑 Stop-loss triggered @ {current_price}¢ — closing {side.upper()}")
                _close_position(side, current_price, ticker, client, paper, paper_mode, reason="stop_loss",
                                entry_price_for_log=entry_price, contracts_for_log=contracts,
                                entry_time_for_log=get_state().get("position", {}).get("entry_time"))
                _release_position()
                _play_caching()
                update_state(position=None)
                return True  # stop-loss

        time.sleep(POLL_INTERVAL)

    # Session ending — let it resolve naturally
    bot_log(f"⏰ Window closing — letting position resolve")
    update_state(position=None, status="resolving")
    _release_position()
    _play_caching()
    # return False after expiry block below

    # Get the position details from state for P&L logging
    pos_state = get_state().get("position") or {}
    pos_entry  = pos_state.get("entry_price", entry_price)
    pos_contracts = pos_state.get("contracts", contracts)
    pos_entry_time = pos_state.get("entry_time", datetime.now(timezone.utc).isoformat())

    if paper_mode:
        import random
        result_price = 95 if random.random() > 0.5 else 5
        paper.close_position(result_price, reason="expiry")
        update_state(paper_stats=paper.stats())
        return False
    else:
        # For live mode: fetch settlement price after a brief wait
        # YES pays $1.00 (100c) if resolved YES, $0.00 (0c) if NO
        # We approximate from the last price — actual settlement logged separately
        time.sleep(3)
        try:
            mkt = safe_call(lambda: client.get_market(ticker), timeout=5, default={})
            last = mkt.get("yes_ask", pos_entry)
            result_price = 100 if last > 90 else (0 if last < 10 else last)
        except Exception:
            result_price = 100 if side == "yes" else 0  # best guess

        # Calculate P&L and log to journal
        if side == "yes":
            pnl = ((result_price - pos_entry) / 100) * pos_contracts
        else:
            pnl = (((100 - result_price) - pos_entry) / 100) * pos_contracts

        live_bal = get_state().get("live_balance")
        trade_record = {
            "ticker":      ticker,
            "side":        side,
            "entry_price": pos_entry,
            "exit_price":  result_price,
            "count":       pos_contracts,
            "pnl":         round(pnl, 4),
            "reason":      "expiry",
            "entry_time":  pos_entry_time,
            "exit_time":   datetime.now(timezone.utc).isoformat(),
            "cash_after":  live_bal,
        }
        journal.log_trade(trade_record)
        pnl_sign = "+" if pnl >= 0 else ""
        bot_log(f"{'✅' if pnl >= 0 else '❌'} Trade closed — P&L: {pnl_sign}${pnl:.2f}")
        return False  # expiry (not stop-loss)


def _close_position(side, exit_price, ticker, client, paper, paper_mode, reason,
                    contracts=None, entry_price_for_log=None, contracts_for_log=None,
                    entry_time_for_log=None):
    if contracts is None:
        contracts = dollars_to_contracts(ORDER_DOLLARS, exit_price)
    for attempt in range(1, MAX_RETRIES + 1):
        if paper_mode:
            paper.close_position(exit_price, reason=reason)
            return
        else:
            try:
                resp = safe_call(lambda: client.place_order(ticker, side, contracts, exit_price, action="sell"), timeout=8, default={})
                order = resp.get("order", {})
                fill_count = float(order.get("fill_count_fp", "0") or order.get("fill_count", 0) or 0)
                if fill_count > 0 or order.get("status") in ("filled", "executed", "canceled"):
                    bot_log(f"  ✅ Position closed (attempt {attempt})")
                    # Log trade P&L for live mode
                    if entry_price_for_log is not None:
                        ep = entry_price_for_log
                        ct = contracts_for_log or contracts
                        if side == "yes":
                            pnl = ((exit_price - ep) / 100) * ct
                        else:
                            pnl = (((100 - exit_price) - ep) / 100) * ct
                        live_bal = get_state().get("live_balance")
                        trade_record = {
                            "id":          len(journal.get_all()) + 1,
                            "ticker":      ticker,
                            "side":        side,
                            "entry_price": ep,
                            "exit_price":  exit_price,
                            "count":       ct,
                            "pnl":         round(pnl, 4),
                            "reason":      reason,
                            "entry_time":  entry_time_for_log or datetime.now(timezone.utc).isoformat(),
                            "exit_time":   datetime.now(timezone.utc).isoformat(),
                            "cash_after":  live_bal,
                        }
                        journal.log_trade(trade_record)
                        pnl_sign = "+" if pnl >= 0 else ""
                        bot_log(f"{'✅' if pnl >= 0 else '❌'} P&L: {pnl_sign}${pnl:.2f}")
                    return
            except Exception as e:
                bot_log(f"  Close error: {e}")
        time.sleep(1)
    bot_log("⚠️  Could not confirm close after 4 retries")


# ─── ENTRY POINT ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    api_key   = os.environ.get("KALSHI_API_KEY", "YOUR_API_KEY_HERE")
    paper_mode = "--live" not in sys.argv  # default to paper mode
    run_bot(api_key, paper_mode=paper_mode)
