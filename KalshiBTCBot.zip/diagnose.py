import base64, datetime, json, os, uuid
import requests
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.backends import default_backend

app_data = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "KalshiBot")
cfg      = json.loads(open(os.path.join(app_data, "kalshi_config.json")).read())
key_id   = cfg.get("api_key", "").strip()
pem_path = cfg.get("pem_path", "").strip()

with open(pem_path, "rb") as f:
    pk = serialization.load_pem_private_key(f.read(), password=None, backend=default_backend())

BASE = "https://api.elections.kalshi.com/trade-api/v2"

def sign(method, path):
    ts = str(int(datetime.datetime.now().timestamp() * 1000))
    full_path = ("/trade-api/v2" + path).split("?")[0]
    msg = (ts + method.upper() + full_path).encode("utf-8")
    sig = base64.b64encode(pk.sign(
        msg,
        asym_padding.PSS(mgf=asym_padding.MGF1(hashes.SHA256()),
                         salt_length=asym_padding.PSS.DIGEST_LENGTH),
        hashes.SHA256()
    )).decode("utf-8")
    return {"KALSHI-ACCESS-KEY": key_id, "KALSHI-ACCESS-TIMESTAMP": ts,
            "KALSHI-ACCESS-SIGNATURE": sig, "Content-Type": "application/json"}

def get(path, params=None):
    r = requests.get(BASE + path, params=params, headers=sign("GET", path))
    print(f"GET {path} -> {r.status_code}")
    return r.json()

def post(path, body):
    r = requests.post(BASE + path, json=body, headers=sign("POST", path))
    print(f"POST {path} -> {r.status_code}")
    print(f"Body sent : {json.dumps(body, indent=2)}")
    print(f"Response  : {r.text}")
    return r.json()

# Balance check
print("=" * 55)
print("BALANCE")
print("=" * 55)
d = get("/portfolio/balance")
cents = d.get("balance", 0)
print(f"Balance: ${cents/100:.2f}")
print()

# Find a usable market
print("=" * 55)
print("MARKETS")
print("=" * 55)
d = get("/markets", params={"series_ticker": "KXBTC15M", "status": "open", "limit": 10})
markets = d.get("markets", [])
good = []
for m in markets:
    yes_ask = float(m.get("yes_ask_dollars", 0.5)) * 100
    no_ask  = float(m.get("no_ask_dollars",  0.5)) * 100
    print(f"  {m['ticker']} yes_ask={yes_ask:.0f}c no_ask={no_ask:.0f}c close={m.get('close_time','?')}")
    if 10 < yes_ask < 90:
        good.append((m, yes_ask, no_ask))
print()

if not good:
    print("No suitable markets (all near 0 or 100). Wait for a fresh window.")
    input("Press Enter...")
    exit()

mkt, yes_ask, no_ask = good[0]
ticker = mkt["ticker"]
print(f"Using: {ticker}  yes_ask={yes_ask:.0f}c  no_ask={no_ask:.0f}c")
print()

# Test YES order at 1c (safe, won't fill)
print("=" * 55)
print("TEST YES ORDER @ 1c (won't fill — just checks auth + format)")
print("=" * 55)
post("/portfolio/orders", {
    "ticker": ticker, "action": "buy", "side": "yes",
    "count": 1, "type": "limit",
    "yes_price": 1,
    "time_in_force": "immediate_or_cancel",
    "client_order_id": str(uuid.uuid4()),
})
print()

# Test NO order at actual trigger price (73c)
print("=" * 55)
print(f"TEST NO ORDER @ 73c (mirrors what bot does when NO hits 70c+)")
print("=" * 55)
post("/portfolio/orders", {
    "ticker": ticker, "action": "buy", "side": "no",
    "count": 1, "type": "limit",
    "yes_price": 27,
    "time_in_force": "immediate_or_cancel",
    "client_order_id": str(uuid.uuid4()),
})
print()

input("Press Enter to exit...")
