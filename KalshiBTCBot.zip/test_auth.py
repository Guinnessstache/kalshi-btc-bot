import base64
import datetime
import requests
import json
import os
import sys
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend

key_id = sys.argv[1].strip() if len(sys.argv) >= 2 else ""
pem_path = sys.argv[2].strip() if len(sys.argv) >= 3 else ""

print("=" * 55)
print("Kalshi Auth Diagnostic")
print("=" * 55)
print("Key ID   :", key_id or "(not set)")
print("Key file :", pem_path or "(not set)")
print()

if not key_id or not pem_path:
    print("Usage: py test_auth.py <key_id> <key_file>")
    print("Example:")
    print("  py test_auth.py b1965b70-xxxx C:\\Users\\you\\kash.txt")
    input("Press Enter to exit...")
    sys.exit(1)

if not os.path.exists(pem_path):
    print("ERROR: File not found:", pem_path)
    input("Press Enter to exit...")
    sys.exit(1)

with open(pem_path, "rb") as f:
    key_data = f.read()

print("Key first line:", key_data.splitlines()[0].decode())

try:
    pk = serialization.load_pem_private_key(key_data, password=None, backend=default_backend())
    print("Key loaded    : OK")
except Exception as e:
    print("Key load FAILED:", e)
    input("Press Enter to exit...")
    sys.exit(1)

ts = str(int(datetime.datetime.now().timestamp() * 1000))
path = "/trade-api/v2/portfolio/balance"
msg = ts + "GET" + path
print("Signing msg   :", msg)

sig = base64.b64encode(pk.sign(
    msg.encode(),
    padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH),
    hashes.SHA256()
)).decode()

print("Signature     :", sig[:30] + "...")
print()
print("Calling Kalshi API...")

r = requests.get(
    "https://api.elections.kalshi.com/trade-api/v2/portfolio/balance",
    headers={
        "KALSHI-ACCESS-KEY": key_id,
        "KALSHI-ACCESS-TIMESTAMP": ts,
        "KALSHI-ACCESS-SIGNATURE": sig,
        "Content-Type": "application/json",
    }
)

print("HTTP Status   :", r.status_code)
print("Response      :", r.text)
print()

if r.status_code == 200:
    print("SUCCESS - auth is working!")
else:
    print("FAILED - check the response above for the reason")
    print()
    print("Common fixes:")
    print("  1. Sync Windows clock: Settings -> Time -> Sync now")
    print("  2. Regenerate key at kalshi.com -> Settings -> API")

input("\nPress Enter to exit...")
